from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from time import sleep
import os
import re


url = input('Escreva o Url da Liga aqui: ')

#Configurações Iniciais ChromeDriver
servico = Service(ChromeDriverManager().install())
navegador = webdriver.Chrome(service=servico)

#Caminho para a pasta onde você deseja salvar os dados
pasta_base = 'Dados'
if not os.path.exists(pasta_base):
    os.makedirs(pasta_base)

#Inciar o Selenium e o Beutiful Soup no URL passado atráves do Input
navegador.get(url)
pagina = navegador.page_source
soup = BeautifulSoup(pagina, 'html.parser')

#Econtrar todos os HiperLinks que tem como padrão o texto /team/football/ na sua composição
elementos_href = soup.find_all('a', href=lambda href: href and '/team/football/' in href)

#Salvar os links na variável links_times com o tipo set() para não haver repetição, visto que é um conjunto
links_times = set()
links_abertos = set()

#Para cada elemento(TIME) encontrado, iniciar uma repetição adicionando todos na variável links_times
for elemento in elementos_href:
    links_times.add(elemento['href'])

#Cria um for para percorrer cada time da lista links_times
for time in links_times:

    #Confere se o time já apareceu na lista links_abertos(links que foram abertos) para não haver repetição e se não estiver, iniciar o looping
    if time not in links_abertos:
        navegador.get('https://www.sofascore.com/' + f'{time}')
        pagina = navegador.page_source
        soup = BeautifulSoup(pagina, 'html.parser')
        
        #Scrapping dos jogadores do time
        elementos_jogadores = soup.find_all('a', href=lambda href: href and '/player/' in href)

        #Aplicando a mesma estratégia anterior para os nomes de jogadores, em uma variável chamada links_jogadores
        nomes_jogadores = []
        links_jogadores = set()

        #Criar um for para adicionar o elemento, que possui o link do jogador, da página para a váriavel links_jogadores
        for elemento in elementos_jogadores:
            links_jogadores.add(elemento['href'])

            #Criando looping para cada jogador na lista de jogadores capturados no site
            for jogador in links_jogadores:

                #Verificando se o jogador não está na lista de links abertos, para não se repetir
                if jogador not in links_abertos:

                    #Repetir processo
                    navegador.get('https://www.sofascore.com/' + f'{jogador}')
                    pagina = navegador.page_source
                    soup = BeautifulSoup(pagina, 'html.parser')

                    #Scrapping dos jogos que o jogador participou
                    partidas = soup.find_all('a', class_='sc-631ef08b-0', href=True)

                    #Achar o nome do jogador na página e extrair o texto com a função get_text()
                    nome_jogador_elemento = soup.find('h2', class_='sc-jEACwC iLVhST')
                    nome_do_jogador = nome_jogador_elemento.get_text()
                        

                    if partidas:
                        
                        #Mesma estratégia novamente para cada partida de cada jogador
                        for links_partidas in partidas:

                            #Separa cada partida do jogador em uma lista para ser extraido as estatisticas do jogador daquela partida
                            partida = links_partidas['href']


                            navegador.get('https://www.sofascore.com/' + f'{partida}')
                            pagina = navegador.page_source
                            soup = BeautifulSoup(pagina, 'html.parser')

                            #Achar especificamente o jogador atual em um espaço específico da tela para poder clicar
                            elemento = soup.find('a', href=f"{str(jogador)}")
                            try:

                                #Utiliza o método WebDriverWait para verificar durante um tempo específico se o elemento está disponível para ser clicado
                                elemento_selenium = WebDriverWait(navegador, 10).until(
                                    EC.element_to_be_clickable((By.XPATH, f"//span[@class='sc-jEACwC kaXmbr'][@title='{nome_do_jogador}']"))
                                )
                                    
                                #Função para clicar no elemento
                                elemento_selenium.click()

                                # Aguardar um pouco
                                sleep(2)
                            except:
                                
                                #Se não estiver dentro dos jogadores titulares, verificar para ver se está entre os reservas
                                try:
                                    elemento_div = WebDriverWait(navegador, 10).until(
                                        EC.element_to_be_clickable((By.XPATH, f"//div[@class='sc-fqkvVR sc-dcJsrY gBgQbz fFmCDf'][@title='{nome_jogador_elemento.get_text()}']"))
                                    )

                                    elemento_div.click()

                                    # Aguardar um pouco
                                    sleep(2)
                                    
                                    #Se não estiver dentre os reservas retornar um erro
                                except Exception as e:
                                    print("Ocorreu um erro, jogador não encontrado na partida. Nem nos titulares, nem nos reservas.")


                            pagina = navegador.page_source
                            soup = BeautifulSoup(pagina, 'html.parser')


                            #Extrair estatisticas do jogador em específico da página
                            try:
                                estatisticas = soup.select_one("#__next > main > div.sc-fqkvVR.sc-dcJsrY.RLTNV.hjYsRn > div > div > div > div.sc-fqkvVR.sc-dLMFU.fLrHMT.gVgUiK.ps.ps--active-y > div:nth-child(1) > div > div:nth-child(3)").get_text()

                                #Se tiver defesas, vai assimilar que é um goleiro, logo vai passar (Decisão do Cliente)
                                if "Saves" in estatisticas:
                                    pass
                                else:
                                    #Usando expressões regulares para extrair os valores requisitados
                                    minutos_jogados = re.search(r'Minutes played(\d+\')', estatisticas).group(1)
                                    chutes_no_gol = re.search(r'Shots on target(\d+)', estatisticas).group(1)
                                    chutes_fora_do_gol = re.search(r'Shots off target(\d+)', estatisticas).group(1)
                                    chutes_bloqueados = re.search(r'Shots blocked(\d+)', estatisticas).group(1)
                                    passes = re.search(r'Touches(\d+)', estatisticas).group(1)

                                    #Cria um arquivo com o nome do jogador
                                    arquivo_txt = os.path.join(pasta_base, f'{nome_do_jogador}.txt')

                                    #Adiciona os dados estatísticos no arquivo
                                    with open(arquivo_txt, 'a') as f:
                                        f.write(f'Partida: {partida}\n')
                                        f.write(f'Minutos Jogados: {minutos_jogados}\n')
                                        f.write(f'Chutes no Gol: {chutes_no_gol}\n')
                                        f.write(f'Chutes Fora do Gol: {chutes_fora_do_gol}\n')
                                        f.write(f'Chutes Bloqueados: {chutes_bloqueados}\n')
                                        f.write(f'Passes: {passes}\n')

                                    
                                    #Printa na tela as informações que foram salvas
                                    print(f'Partida: https://www.sofascore.com/{partida}')
                                    print(f"Minutos Jogados: {minutos_jogados}")
                                    print(f"Chutes no Gol: {chutes_no_gol}")
                                    print(f"Chutes Fora do Gol: {chutes_fora_do_gol}")
                                    print(f"Chutes Bloqueados: {chutes_bloqueados}")
                                    print(f"Passes: {passes}")
                                    
                                    #Confirma
                                    print("\nArquivo de texto criado com sucesso!\n")
                            
                            except:
                                #Criando Pasta Erros para poder concertar e não perder os dados de tal jogador
                                pasta_erro = 'Erros'
                                if not os.path.exists(pasta_erro):
                                    os.makedirs(pasta_erro)
                                
                                #Adiconando informações do em um arquivo txt com o nome especifico do jogador
                                arquivo_txt = os.path.join(pasta_erro, f'{nome_do_jogador}.txt')
                                with open(arquivo_txt, 'a') as f:
                                        f.write(f'Ocorreu um erro para obter as Estatisticas, revise o jogo: {partida}\n')

                                print(f'Ocorreu um erro para obter as Estatisticas, revise o jogo: {partida}\n')

                    

                    #Adicionar jogador aos links abertos
                    print(jogador)
                    links_abertos.add(jogador)
